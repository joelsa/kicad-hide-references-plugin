from .hide_references_action import HideReferencesAction # Note the relative import!
HideReferencesAction().register() # Instantiate and register to Pcbnew